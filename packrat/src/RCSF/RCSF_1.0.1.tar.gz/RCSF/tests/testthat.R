library(testthat)
library(RCSF)

test_check("RCSF")
