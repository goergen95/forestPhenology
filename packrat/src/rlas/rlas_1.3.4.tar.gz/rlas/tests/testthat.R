library(testthat)
library(rlas)

test_check("rlas")
